package com.g6ciclo2reto03.g6ciclo2reto03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G6ciclo2reto03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
