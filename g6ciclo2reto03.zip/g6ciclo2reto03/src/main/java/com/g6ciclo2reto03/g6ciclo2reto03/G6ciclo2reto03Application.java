package com.g6ciclo2reto03.g6ciclo2reto03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G6ciclo2reto03Application {

	public static void main(String[] args) {
		SpringApplication.run(G6ciclo2reto03Application.class, args);
	}

}
